import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomeScreen extends StatefulWidget {
  final String currentUserId;

  const HomeScreen({super.key, required this.currentUserId});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<dynamic>> usersFuture;
  Map<String, String> requestStatuses = {}; // userId -> status

  // For search functionality
  TextEditingController searchController = TextEditingController();
  String searchQuery = '';

  @override
  void initState() {
    super.initState();
    usersFuture = getUsers();

    searchController.addListener(() {
      setState(() {
        searchQuery = searchController.text.trim().toLowerCase();
      });
    });
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<List<dynamic>> getUsers() async {
    final url = Uri.parse('https://devtechtop.com/store/public/api/all_user');

    try {
      final response = await http.post(
        url,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: {
          'user_id': widget.currentUserId,
        },
      );

      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded['status'] == 'success' && decoded['data'] is List) {
          final users = decoded['data']
              .where((user) => user['id'].toString() != widget.currentUserId)
              .toList();
          return users;
        } else {
          throw Exception('Invalid user data format');
        }
      } else {
        throw Exception('Failed to load users');
      }
    } catch (e) {
      throw Exception('Error fetching users: $e');
    }
  }

  Future<void> sendFriendRequest(String receiverId) async {
    final url = Uri.parse('https://devtechtop.com/store/public/api/scholar_request/insert');

    try {
      final response = await http.post(
        url,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'sender_id': widget.currentUserId,
          'receiver_id': receiverId,
          'description': 'Hi, I\'d like to connect!',
        }),
      );

      final responseBody = jsonDecode(response.body);
      final status = responseBody['status'] ?? '';
      final errors = responseBody['errors'];

      if (response.statusCode == 200 && status == 'success') {
        setState(() {
          requestStatuses[receiverId] = 'pending';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Request sent to user ID $receiverId')),
        );
      } else if (errors != null) {
        final errorText = errors.toString();
        if (errorText.contains('Duplicate Record')) {
          setState(() {
            requestStatuses[receiverId] = 'pending';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('You have already sent a request to this user.')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed: $errorText')),
          );
        }
      } else {
        final msg = responseBody['message'] ?? responseBody.toString();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $msg')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Color getButtonColor(String status) {
    switch (status) {
      case 'accepted':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      case 'pending':
        return Colors.grey;
      default:
        return Colors.lightBlue;
    }
  }

  String getButtonText(String status) {
    switch (status) {
      case 'accepted':
        return 'Accepted';
      case 'rejected':
        return 'Rejected';
      case 'pending':
        return 'Pending';
      default:
        return 'Send Request';
    }
  }

  bool isButtonDisabled(String status) {
    return status == 'pending' || status == 'accepted' || status == 'rejected';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('All Users')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search users...',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<dynamic>>(
              future: usersFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return const Center(child: Text('No users found.'));
                }

                final filteredUsers = snapshot.data!.where((user) {
                  final name = (user['name'] ?? '').toString().toLowerCase();
                  final email = (user['email'] ?? '').toString().toLowerCase();
                  return name.contains(searchQuery) || email.contains(searchQuery);
                }).toList();

                if (filteredUsers.isEmpty) {
                  return const Center(child: Text('No users match your search.'));
                }

                return ListView.builder(
                  itemCount: filteredUsers.length,
                  itemBuilder: (context, index) {
                    final user = filteredUsers[index];
                    final receiverId = user['id'].toString();
                    final status = requestStatuses[receiverId] ?? 'none';

                    return ListTile(
                      title: Text(user['name'] ?? 'No Name'),
                      subtitle: Text(user['email'] ?? 'No Email'),
                      trailing: ElevatedButton(
                        onPressed: isButtonDisabled(status)
                            ? null
                            : () => sendFriendRequest(receiverId),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: getButtonColor(status),
                        ),
                        child: Text(getButtonText(status)),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
